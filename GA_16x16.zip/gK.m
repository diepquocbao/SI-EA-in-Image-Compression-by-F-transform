function [y] = gK(a,c,b,x)
%Name: h�m tam gi�c d�ng x�c ??nh fuzzy partition 

    y=min(max(0,(x-a)/(c-a)),1)+min(max(0,(x-b)/(c-b)),1)-1;
    
end

