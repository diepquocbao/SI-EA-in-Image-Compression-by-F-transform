%% Image Compression using GA
% |Created by Diep on Nov 27, 2022.|
%% 
% * image size: 32x32 + 64x64 + 128x128
% * select 10 images for testing
% * each image will be tested on 3 algorithms
% * each image: length(xnode) = length(ynode) = 1/4 + 1/2 + 3/4
% * For example: 32x32
% * M = N = 14 (for 1/2)
%% |Load All Images from disk|
clear all; clc; rng(0); %#ok

Io = imread('cameraman.tif');
I  = mat2gray(Io);

I = imresize(I,[16 16]);
M = 4;
N = 4;

[sIr, sIc]  = size(I);
%--------------------------------------------------------------------------
fun   = @(x) CostFunc_GA(I,x,M,N);
nvars = M+N-4;
% Create Linear inequality constraints, specified as a real matrix.
% A is an n-by-nvars matrix, where n is the number of inequalities.
    A = zeros(M+N-4);
    for i = 1:M+N-5
        if i ~= M-2
            A(i,i)   =  1;
            A(i,i+1) = -1;
        end
    end
% Create Linear inequality constraints b, specified as a real vector.
% b is an M-element vector related to the A matrix.
    b        = zeros(M+N-4,1)-1;
    b(M-2)   = 0;
    b(M+N-4) = 0;
% Lower bounds, specified as a real vector or array of doubles.
% lb represents the lower bounds element-wise in lb ≤ x ≤ ub.
% Example: lb = [0;-Inf;4] means x(1) ≥ 0, x(3) ≥ 4.
    lb = zeros(1,M+N-4)+2;
% Upper bounds, specified as a real vector or array of doubles.
% ub represents the upper bounds element-wise in lb ≤ x ≤ ub.
% Example: ub = [Inf;4;10] means x(2) ≤ 4, x(3) ≤ 10.
    ub = [zeros(1,M-2)+sIc-1 zeros(1,N-2)+sIr-1];
% Integer variables, specified as a vector of positive integers taking values from 1 to nvars.
% Each value in intcon represents an x component that is integer-valued.
% Example: To specify that the even entries in x are integer-valued, set intcon to 2:2:nvars
    intcon = 1:M+N-4;
% Create optimization options
% opts = optimoptions('ga','PopulationSize',100,'CrossoverFraction',0.8,'InitialPopulationRange',[0;sIr],'FitnessLimit',MaxFEs,'FunctionTolerance',1e-6);
% opts = optimoptions('ga','PopulationSize',100,'EliteCount',20,'CrossoverFraction',0.99,'InitialPopulationRange',[0;sIr],'MaxStallGenerations',5000,'FunctionTolerance',1e-6,...
%     'MaxGenerations',10000,'UseParallel',false,'PlotFcn',@gaplotbestfun);

opts = optimoptions('ga', ...
    'PopulationSize',100, ...
    'InitialPopulationRange',[0;sIr], ...
    'FunctionTolerance',1e-50,...
    'FitnessLimit',1e-50, ...
    'UseParallel',false, ...
    'ConstraintTolerance',1e-50, ...
    'MaxGenerations', 1000, ...
    'MaxStallGenerations', 1e5);
%--------------------------------------------------------------------------
% Optimization using GA of MATLAB
% [x,fval] = ga(fun,nvars,A,b,[],[],lb,ub,[],intcon,opts);

% [x,fval,exitflag,output,population,scores] = ga(fun,nvars,A,b,[],[],lb,ub,[],intcon,opts)
[x,fval,exitflag,output,~,~] = ga(fun,nvars,A,b,[],[],lb,ub,[],intcon,opts)
%--------------------------------------------------------------------------
% Return xnode and ynode values
xnode    = [1  x(1:M-2)     sIc] %#ok
ynode    = [1  x(M-1:M+N-4) sIr] %#ok

%------- The End --------
% Day la file chuan, da test OK.




