function fit = CostFunc_GA(I,x,M,N)
% Diep modified here, on Nov 27, 2022.
    [sIr, sIc]  = size(I);
    % Extract Vector x into xnode and ynode
    xnode = [1  x(1:M-2)     sIc];
    ynode = [1  x(M-1:M+N-4) sIr];
    % Image Compression Algorithm
    IV    = FIMR(I,xnode,ynode);
    % Calculate RMSE of two pics
    fit   = rmse(I,IV,"all");
end

