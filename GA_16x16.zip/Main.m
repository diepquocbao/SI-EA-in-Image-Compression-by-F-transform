%% Image Compression using GA
% |Created by Diep on Nov 27, 2022.|
%% 
% * image size: 32x32 + 64x64 + 128x128
% * select 10 images for testing
% * each image will be tested on 3 algorithms
% * each image: length(xnode) = length(ynode) = 1/4 + 1/2 + 3/4
% * For example: 32x32
% * M = N = 14 (for 1/2)
%% |Load All Images from disk|
clear all; clc; rng(0); %#ok

ids     = imageDatastore("a*.jpg");
numPics = length(ids.Files);
numRuns = 25; % Run the algorithm 30 times
numall  = numPics*numRuns;
%Max_FEs = 1e5; % MaxFEs = 100.000
% Define M and N
Size = 16;  % 32  + 64  + 128
% scl  = 1/2; % 1/2 + 1/4 + 3/4
% M    = Size*scl-2;
% N    = Size*scl-2;
M = 8;
N = M;
% Define costfunction
% fun    = @(x)CostFunc_GA(I,x,M,N);
nvars    = M+N-4;
% Pre-define xnode and ynode for 10 images and 30 runs
XNODE1   = zeros(numall,M);
YNODE1   = zeros(numall,N);
FVAL1    = zeros(numall);
isSOL1   = zeros(numall);
Timer1   = zeros(numall);
% Run in paralell
AllPics  = readall(ids);
AllPics  = repelem(AllPics,numRuns);
parfor num  = 1 : numall
    tic
    % Extract one pic
    ith  = AllPics{num};
    % Convert the image from RGB to gray and double, resize the image
    Io   = rgb2gray(ith);
    I    = imresize(Io, [Size,Size]);
    I    = mat2gray(I);
    %----------------------------------------------------------------------
    [sIr, sIc] = size(I);
    A = zeros(M+N-4);
    for i = 1:M+N-5
        if i ~= M-2
            A(i,i)   =  1;
            A(i,i+1) = -1;
        end
    end
    b        = zeros(M+N-4,1)-1;
    b(M-2)   = 0;
    b(M+N-4) = 0;
    lb = zeros(1,M+N-4)+2;
    ub = [zeros(1,M-2)+sIc-1 zeros(1,N-2)+sIr-1];
    intcon = 1:M+N-4;
    opts = optimoptions('ga', ...
            'PopulationSize',100, ...
            'InitialPopulationRange',[0;sIr], ...
            'FunctionTolerance',1e-50,...
            'FitnessLimit',1e-50, ...
            'UseParallel',false, ...
            'ConstraintTolerance',1e-50, ...
            'MaxGenerations', 1000, ...
            'MaxStallGenerations', 1e5);
    %----------------------------------------------------------------------
    tic
    % Optimization using GA of MATLAB
    fun   = @(x) CostFunc_GA(I,x,M,N);
    [y,fval,exitflag,output,~,~] = ga(fun,nvars,A,b,[],[],lb,ub,[],intcon,opts);
    % handling some variables
    xnode    = [1  y(1:M-2)     sIc];
    ynode    = [1  y(M-1:M+N-4) sIr];
    if exitflag >= 0
        issol = 1;
    else
        issol = 0;
    end
    %----------------------------------------------------------------------
    % Store the values
    XNODE1(num,:) = xnode;
    YNODE1(num,:) = ynode;
    FVAL1(num)    = fval;
    isSOL1(num)   = issol;
    Timer1(num)   = toc;
end
%--------------------------------------------------------------------------
% Reshape the results
% Pre-define xnode and ynode for 10 images and 30 runs
XNODE    = zeros(numRuns,M,numPics);
YNODE    = zeros(numRuns,N,numPics);
FVAL     = zeros(numRuns,numPics);
isSOL    = zeros(numRuns,numPics);
Timer    = zeros(numRuns,numPics);
for ii = 1:numall
    runs = rem(ii,numRuns);
    if runs==0
        runs = numRuns;
    end
    pics = ceil(ii/numRuns); % Round toward positive infinity
    % Store the values
    XNODE(runs,:,pics) = XNODE1(ii,:);
    YNODE(runs,:,pics) = YNODE1(ii,:);
    FVAL(runs,pics)    = FVAL1(ii);
    isSOL(runs,pics)   = isSOL1(ii);
    Timer(runs,pics)   = Timer1(ii);
end

save GA_WorkSpace_16x16_8.mat
isSOL %#ok
% runs = 2;
% pics = 5;
% IMC  = gIMC(I,XNODE(runs,:,pics),YNODE(runs,:,pics));
% DIMC = gDIMC(y, XNODE(runs,:,pics),YNODE(runs,:,pics));
% montage({I,IMC,DIMC})










