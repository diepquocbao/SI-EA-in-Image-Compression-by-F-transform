function pop = CheckBoundary(pop,sIr,sIc,M,N)
    % Kiem tra ranh gioi va thay the cac ca the ngoai ranh gioi
    
    pop = round(pop);
    pop = max(pop,1);
    pop(:,1:M-2)       = min(pop(:,1:M-2),sIc-1);
    pop(:,M-2+1:M+N-4) = min(pop(:,M-2+1:M+N-4),sIr-1);
end