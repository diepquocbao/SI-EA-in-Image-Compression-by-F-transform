% The superiority of feasible solutions for constraint handling methods
function [xnode,ynode,thegbestval,isSol] = SF_DE(I,M,N,Max_FEs)
%==========================================================================
% Load the image
% I = imread('cameraman.tif');
% I = mat2gray(I); % Convert to grayscale
% I = imresize(I,[32 32]); % Resize the image to 64x64 for example
% M = 5; % The number of output picture (x)
% N = 5; % The number of output picture (y)
CostFunction = @(pop,I,M,N)     CostFunc(pop,I,M,N);
%==========================================================================
NP       = 100;                 % Size of Population
Max_Gen  = round(Max_FEs/NP);  % Maximum number of generations
F        = 0.7;         % 0.7
Cr       = 0.3;         % 0.9
D        = M+N-4;       % Dimension of the problem
[sIr,sIc]= size(I);
isSol    = 0;           % Co nghiem: isSol=1; KHONG cos nghiem: isSol=0
%==========================================================================
pop    = zeros(NP,D); % Create Initial Population, pop=NPxD
for id = 1:NP
    pop(id,1:M-2)        = randperm(sIc,M-2);
    pop(id,M-2+1:M+N-4)  = randperm(sIr,N-2);
end
[val, g, h] = CostFunction(pop,I,M,N);
FEs         = NP;
%---------------------------------
CONV = abs(h);
if(~isempty(CONV) && ~isempty(find(CONV>0, 1)))
    DELTA   = median(median(CONV,2));
else
    DELTA   = 10^(-4);
end
%==========================================================================
rot = 0 : NP-1;
for gen = 1:Max_Gen
    FM_mui  = rand(NP,D) < Cr;
	ind     = randperm(2);
	A1      = randperm(NP);
	rt1     = rem(rot+ind(1),NP)+1;
	A2      = A1(rt1);
	rt2     = rem(rot+ind(2),NP)+1;
	A3      = A2(rt2);
	newpop  = pop(A1,:) + F*(pop(A2,:)-pop(A3,:));
	newpop  = pop.*not(FM_mui) + newpop.*FM_mui;
    %---------------------------------
    newpop  = CheckBoundary(newpop,sIr,sIc,M,N);
    %---------------------------------
    [newval, newg, newh] = CostFunction(newpop,I,M,N);
    FEs = FEs + NP;
    %---------------------------------
    A = [pop ; newpop];
    B = [val ; newval];
    G = [g   , newg];
    H = [h   , newh];
    %==================================================================
    % Calculate: Superiority of Feasible Solutions (see Eq.3)
    % Cho cac rang buoc am cua G va (abs(H)-DELTA) bang 0
    cons3       = [max(0,G) ; max(0,(abs(H)-DELTA))]';
    cons_max3   = max(cons3,[],1);
    nzindex3    = find(cons_max3~=0);
    if isempty(nzindex3)
        tcons3  = zeros(size(A,1),1);
    else
        wi      = 1./cons_max3(:,nzindex3);
        tcons3  = sum(cons3(:,nzindex3).*wi , 2) ./ sum(wi);
    end 
    % So sanh theo cac muc A.1,2,3 trong bai bao
    for kk = 1:NP
        DK1 = tcons3(NP+kk) < tcons3(kk);
        DK2 = tcons3(NP+kk) == 0;
        DK3 = tcons3(kk) == 0;
        DK4 = B(NP+kk) <= B(kk);
        if DK1 || (DK2 && DK3 && DK4)
            pop(kk,:) = A(NP+kk,:);
            val(kk,:) = B(NP+kk,:);
            g(:,kk)   = G(:,NP+kk);
            h(:,kk)   = H(:,NP+kk);
        end
    end
    %---------------------------------
    % Cho cac rang buoc am cua G va abs(h)-10^(-4) bang 0
    cons5       = [max(0,g) ; max(0,abs(h)-10^(-4))]';
    cons_max5   = max(cons5,[],1);
    nzindex5    = find(cons_max5~=0);
    %---------------------------------
    if isempty(nzindex5)
        tcons5  = zeros(NP,1);
    else
        wi      = 1./cons_max5(:,nzindex5);
        tcons5  = sum(cons5(:,nzindex5).*wi , 2) ./ sum(wi);
    end 
    %---------------------------------
    feasindex = find(tcons5==0);
    if isempty(feasindex)
        [gbesttcons,ibest]  = min(tcons5);
        gbestval            = val(ibest);
        gbest               = pop(ibest,:);
    else
        isSol = 1; % we've got at least one solution
        [gbestval,ibest]    = min(val(feasindex));
        gbesttcons          = tcons5(feasindex(ibest));
        gbest               = pop(feasindex(ibest),:);
    end
    %---------------------------------
    if gen==1
        thegbestval     = gbestval;
        thegbest        = gbest;
        thegbesttcons   = gbesttcons;
    elseif((gbesttcons  < thegbesttcons) || (gbesttcons==0 && thegbesttcons ==0 && gbestval < thegbestval))
        thegbestval     = gbestval;
        thegbest        = gbest;
        thegbesttcons   = gbesttcons;
    end
end
%==========================================================================
xnode   = [1 thegbest(1:M-2) sIc];
ynode   = [1 thegbest(M-1:M+N-4) sIr];
%==========================================================================
end
