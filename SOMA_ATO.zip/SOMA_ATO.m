% ------ SOMA Simple Program       ---  Version: All To One (Original) ----
% ------ Written by: Quoc Bao DIEP ---  Email: diepquocbao@gmail.com   ----
% -----------  See more details at the end of this file  ------------------
function [xnode,ynode,thegbestval,isSol] = SOMA_ATO(I,M,N,Max_FEs)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I = imread('cameraman.tif'); % Load the image
% I = mat2gray(I);         % Convert to grayscale
% I = imresize(I,[64 64]); % Resize the image to 64x64 for example
% M = 46;                  % The number of output nodes (x)
% N = 46;                  % The number of output nodes (y)
D = M+N-4;               % Dimension of the problem
[sIr,sIc] = size(I);     % Size of the image
isSol = 0;               % Co nghiem: isSol=1; KHONG cos nghiem: isSol=0
CostFunction = @(pop,I,M,N)     CostFunc(pop,I,M,N);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% -------------- Initial Parameters of SOMA -------------------------------
% Max_FEs    = 1e5;      % Define the stop condition
Step       = 0.11;       % Define the Step parameter
PRT        = 0.08;        % Define the PRT parameter
NP         = 100;        % Define the number individuals of the population
PathLength = 2.0;        % Define the PathLength parameter
step       = Step:Step:PathLength;
offLength  = floor(numel(step));
%             E N D    O F   U S E R    D E F I N I T I O N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    B E G I N    S O M A
% ------------------- Create Initial Population ---------------------------
pop = zeros(NP,D);
for id = 1:NP
    pop(id,1:M-2)        = randperm(sIc,M-2);
    pop(id,M-2+1:M+N-4)  = randperm(sIr,N-2);
end
[fitness, g, h] = CostFunction(pop,I,M,N);
FEs = NP;

[~,id] = min(fitness);
leader = pop(id,:);
%---------------------------------
CONV = abs(h);
if(~isempty(CONV) && ~isempty(find(CONV>0, 1)))
    DELTA   = median(median(CONV,2));
else
    DELTA   = 10^(-4);
end
% ---------------- SOMA MIGRATIONS ----------------------------------------
thegbestval    = Inf;
thegbest       = Inf;
thegbesttcons  = Inf;
Migration      = 0;
while FEs < Max_FEs
    Migration  = Migration + 1;
    % ------------ movement of each individual ----------------------------
    for j = 1 : NP
        indi_moving = pop(j,:);
        if j ~= id
            off_path = zeros(offLength,D);
            for k = 1:offLength
                %----- SOMA Mutation --------------------------------------
                PRTVector     = rand(1,D) < PRT;
                %----- SOMA Crossover -------------------------------------
                offspring     =  indi_moving+(leader-indi_moving)*step(k).*PRTVector;
                off_path(k,:) = offspring;
            end % END JUMPING
            %-- Check the boundary and replace the Individuals that out of the search-space
            off_path = CheckBoundary(off_path,sIr,sIc,M,N);
            %----- Evaluate the offspring ---------------------------------
            [new_cost, newg, newh] = CostFunction(off_path,I,M,N);
            FEs = FEs + offLength;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            G = [newg , g(:,j)];
            H = [newh , h(:,j)];
            %==============================================================
            % Calculate: Superiority of Feasible Solutions (see Eq.3)
            % Cho cac rang buoc am cua G va (abs(H)-DELTA) bang 0
            cons3       = [max(0,G) ; max(0,(abs(H)-DELTA))]';
            cons_max3   = max(cons3,[],1);
            nzindex3    = find(cons_max3~=0);
            if isempty(nzindex3)
                tcons3  = zeros(offLength+1,1);
            else
                wi      = 1./cons_max3(:,nzindex3);
                tcons3  = sum(cons3(:,nzindex3).*wi , 2) ./ sum(wi);
            end 
            % So sanh theo cac muc A.1,2,3 trong bai bao
            %--------------------------------------------------------------
            if tcons3(end) == 0 % if Xi is feasible
                comp = tcons3(1:offLength) == 0;
                if sum(comp) > 0 % if any Xj is feasible
                    if sum(new_cost <= fitness(j)) > 0 %
                        [~,idc] = min(new_cost(comp));
                        pop(j,:) = off_path(idc,:);
                        fitness(j) = new_cost(idc);
                        g(:,j)    = newg(:,idc);
                        h(:,j)    = newh(:,idc);
                    end
                end
            elseif sum(tcons3(1:offLength) < tcons3(end)) > 0
                [~, idt]   = min(tcons3(1:offLength));
                pop(j,:)   = off_path(idt,:);
                fitness(j) = new_cost(idt);
                g(:,j)     = newg(:,idt);
                h(:,j)     = newh(:,idt);
            end
            %--------------------------------------------------------------
            % Cho cac rang buoc am cua G va abs(h)-10^(-4) bang 0
            cons5       = [max(0,g) ; max(0,abs(h)-10^(-4))]';
            cons_max5   = max(cons5,[],1);
            nzindex5    = find(cons_max5~=0);
            %---------------------------------
            if isempty(nzindex5)
                tcons5  = zeros(NP,1);
            else
                wi      = 1./cons_max5(:,nzindex5);
                tcons5  = sum(cons5(:,nzindex5).*wi , 2) ./ sum(wi);
            end 
            %---------------------------------
            feasindex = find(tcons5==0);
            if isempty(feasindex)
                [gbesttcons,ibest]  = min(tcons5);
                gbestval            = fitness(ibest);
                gbest               = pop(ibest,:);
            else
                isSol = 1; % we've got at least one solution
                [gbestval,ibest]    = min(fitness(feasindex));
                gbesttcons          = tcons5(feasindex(ibest));
                gbest               = pop(feasindex(ibest),:);
            end
			leader = gbest;
            %---------------------------------
            if((gbesttcons  < thegbesttcons) || (gbesttcons==0 && thegbesttcons ==0 && gbestval < thegbestval))
                thegbestval     = gbestval;
                thegbest        = gbest;
                thegbesttcons   = gbesttcons;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end % END if
    end  % END PopSize   (For Loop)
end   % END MIGRATIONS (While Loop)
% Show the information to User
xnode = [1 thegbest(1:M-2) sIc];
ynode = [1 thegbest(M-1:M+N-4) sIr];
end