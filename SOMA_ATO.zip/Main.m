%% Image Compression using SOMA-ATO
% |Created by Diep on Nov 23, 2022.|
%% 
% * image size: 32x32 + 64x64 + 128x128
% * select 10 images for testing
% * each image will be tested on 3 algorithms
% * each image: length(xnode) = length(ynode) = 1/4 + 1/2 + 3/4
% * For example: 32x32
% * M = N = 14 (for 1/2)
%% |Load All Images from disk|

clear all; clc; rng(0) %#ok

ids     = imageDatastore("a*.jpg");
numPics = length(ids.Files);
numRuns = 25; % Run the algorithm 30 times
numall  = numPics*numRuns;
Max_FEs = 1e5; % MaxFEs = 100.000
% Define M and N
Size = 16;  % 32  + 64  + 128
scl  = 3/4; % 1/2 + 1/4 + 3/4
M    = Size*scl-2;
N    = Size*scl-2;
% Pre-define xnode and ynode for 10 images and 30 runs
XNODE1   = zeros(numall,M);
YNODE1   = zeros(numall,N);
FVAL1    = zeros(numall);
isSOL1   = zeros(numall);
Timer1   = zeros(numall);
% Run in paralell
AllPics  = readall(ids);
AllPics  = repelem(AllPics,numRuns);
parfor num  = 1 : numall
    tic
    % Extract one pic
    ith  = AllPics{num};
    % Convert the image from RGB to gray and double, resize the image
    Io   = rgb2gray(ith);
    I    = imresize(Io, [Size,Size]);
    I    = mat2gray(I);
    % Find xnode and ynode
    [xnode,ynode,fval,issol] = SOMA_ATO(I,M,N,Max_FEs);
    % Store the values
    XNODE1(num,:) = xnode;
    YNODE1(num,:) = ynode;
    FVAL1(num)    = fval;
    isSOL1(num)   = issol;
    Timer1(num)   = toc;
end
% Reshape the results
% Pre-define xnode and ynode for 10 images and 30 runs
XNODE    = zeros(numRuns,M,numPics);
YNODE    = zeros(numRuns,N,numPics);
FVAL     = zeros(numRuns,numPics);
isSOL    = zeros(numRuns,numPics);
Timer    = zeros(numRuns,numPics);
for ii = 1:numall
    runs = rem(ii,numRuns);
    if runs==0
        runs = numRuns;
    end
    pics = ceil(ii/numRuns); % Round toward positive infinity
    % Store the values
    XNODE(runs,:,pics) = XNODE1(ii,:);
    YNODE(runs,:,pics) = YNODE1(ii,:);
    FVAL(runs,pics)    = FVAL1(ii);
    isSOL(runs,pics)   = isSOL1(ii);
    Timer(runs,pics)   = Timer1(ii);
end

save SOMA_WorkSpace_12_16.mat

% runs = 2;
% pics = 5;
% IMC  = gIMC(I,XNODE(runs,:,pics),YNODE(runs,:,pics));
% DIMC = gDIMC(y, XNODE(runs,:,pics),YNODE(runs,:,pics));
% montage({I,IMC,DIMC})



