function [y] = FIMR(I,xnode,ynode)

n=size(xnode);
n=n(2);
m=size(ynode);
m=m(2);
%% Code 
bot=I(ynode(m-1):ynode(m)-1,:);
bot=flip(bot);
top=I(2:ynode(2),:);
top=flip(top);

II=[top; I ; bot];

left=II(:,2:xnode(2));
left=flip(left,2);
right=II(:,xnode(n-1):xnode(n)-1);
right=flip(right,2);

III=[left II right];
%% Giai thuat nen
q1 = size(III);
xnode1 = [1, xnode+(xnode(2)-1), q1(2)];
ynode1 = [1, ynode+(ynode(2)-1), q1(1)];
n=size(xnode1);
n=n(2);
m=size(ynode1);
m=m(2);

R=zeros(ynode1(m),xnode1(n));
for i=2:n-1
    for j=2:m-1
        Iij=III(ynode1(j-1):ynode1(j+1),xnode1(i-1):xnode1(i+1));
        Aij=transpose(gK(ynode1(j-1),ynode1(j),ynode1(j+1),ynode1(j-1):ynode1(j+1)))*gK(xnode1(i-1),xnode1(i),xnode1(i+1),xnode1(i-1):xnode1(i+1));
        tempij=Iij.*Aij;
        Rij=zeros(ynode1(m),xnode1(n));
        Rij(ynode1(j-1):ynode1(j+1),xnode1(i-1):xnode1(i+1))=(sum(sum(tempij))/sum(sum(Aij)))*Aij;
        R=R+Rij;        
    end
end

y = R(ynode1(2):ynode1(m-1),xnode1(2):xnode1(n-1));
%y=mat2gray(F);
end