% Cost Function 
function [fit, g, h] = CostFunc(pop,I,M,N)
    [sIr, sIc]  = size(I);
    [NP, ~]     = size(pop);
    Xnode       = pop(:,1:M-2);
    Ynode       = pop(:,M-1:M+N-4);
    %----------------------------------------
    fit         = zeros(NP,1);
    h           = zeros(1,NP);
    g           = zeros(M-2+N-2,NP); % calculate the diff between n elemants needs n-1 loops
    for np = 1:NP
        %----------------------------------------
        xnode   = [1 Xnode(np,:) sIc];
        ynode   = [1 Ynode(np,:) sIr];
        %----------------------------------------
        % Calculate g(x): InEquality Constraint
        g(1,np) = 1 - Xnode(np,1) + 1;
        for iM = 1 : M-3 % NOT M-2: calculate the diff between n elemants needs n-1 loops
            g(iM+1,np)    = Xnode(np,iM) - Xnode(np,iM+1) + 1;
        end
        g(iM+2,np) = 1 - Ynode(np,1) + 1;
        for iN = 1 : N-3 % Consider: M+N-4 OR M+N-5
            g(iN+iM+2,np) = Ynode(np,iN) - Ynode(np,iN+1) + 1;
        end
        %----------------------------------------
        % Calculate h(x): Equality Constraintr
        h(np)   = 0;
        %----------------------------------------
        % Calculate f(x): Cost Value
        %F      = gIMC( I,xnode,ynode);
        %IV     = gDIMC(F,xnode,ynode);
        IV      = FIMR(I,xnode,ynode);
        E       = (I-IV).^2;
        SE      = sum(sum(E));
        MSE     = SE/(sIr*sIc);
        fit(np) = sqrt(MSE);
        %----------------------------------------
    end
end